import React, { useEffect, useState, useRef } from "react";

type Enquiry = {
  fullName: string;
  businessEmail: string;
  companyName?: string;
  enquiryType: string;
  message: string;
};

type StoredEnquiry = {
  id: string;
  value: Enquiry & { createdAt: string };
};

const LOGO_SVG = () => (
  <svg width="36" height="36" viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <linearGradient id="lg1" x1="4" y1="28" x2="32" y2="4" gradientUnits="userSpaceOnUse">
        <stop stopColor="#24D6E8" />
        <stop offset="1" stopColor="#17BFA3" />
      </linearGradient>
    </defs>
    <path d="M18 3C18 3 10 12 10 19C10 23.4183 13.5817 27 18 27C22.4183 27 26 23.4183 26 19C26 12 18 3 18 3Z" fill="url(#lg1)" />
    <path d="M6 23C8.5 21.5 12 22 14.5 24C17 26 20 26 22.5 24C25 22 28.5 21.5 30 23" stroke="white" strokeWidth="1.2" strokeLinecap="round" opacity="0.9" />
    <path d="M7 27C9 25.8 12 26.2 14.8 27.6C17.6 29 20.4 29 23.2 27.6C26 26.2 29 25.8 31 27" stroke="white" strokeWidth="1.2" strokeLinecap="round" opacity="0.7" />
    <circle cx="18" cy="6" r="1.5" fill="#073B5C" />
  </svg>
);

// ---- SVG ICONS FOR FOCUS ----
const ExploreIcon = () => (
  <svg width="68" height="68" viewBox="0 0 68 68" fill="none">
    <circle cx="34" cy="34" r="26" stroke="white" strokeWidth="1.5" opacity="0.9"/>
    <circle cx="34" cy="34" r="18" stroke="white" strokeWidth="1" opacity="0.5" strokeDasharray="4 4"/>
    <path d="M34 14 L34 54 M14 34 L54 34" stroke="white" strokeWidth="1" opacity="0.4"/>
    <path d="M41 27 L27 41 L31 44 L44 31 Z" fill="white" opacity="0.95"/>
    <circle cx="34" cy="34" r="3" fill="white"/>
  </svg>
);
const FactoryIcon = () => (
  <svg width="68" height="68" viewBox="0 0 68 68" fill="none">
    <rect x="12" y="28" width="44" height="24" rx="3" stroke="white" strokeWidth="1.5" opacity="0.9"/>
    <rect x="18" y="34" width="6" height="6" rx="1" fill="white" opacity="0.9"/>
    <rect x="28" y="34" width="6" height="6" rx="1" fill="white" opacity="0.6"/>
    <rect x="38" y="34" width="10" height="6" rx="1" fill="white" opacity="0.4"/>
    <path d="M18 28 V16 H24 V28 M30 28 V14 H36 V28 M42 28 V18 H48 V28" stroke="white" strokeWidth="1.5" strokeLinecap="round"/>
    <path d="M14 52 H54" stroke="white" strokeWidth="1.2" opacity="0.5"/>
  </svg>
);
const PipelineIcon = () => (
  <svg width="68" height="68" viewBox="0 0 68 68" fill="none">
    <path d="M12 34 H38 C42 34 46 30 46 26 V18" stroke="white" strokeWidth="1.6" strokeLinecap="round"/>
    <path d="M12 44 H42 C48 44 52 40 52 34 V26" stroke="white" strokeWidth="1.6" strokeLinecap="round" opacity="0.7"/>
    <circle cx="56" cy="18" r="5" stroke="white" strokeWidth="1.5"/>
    <circle cx="56" cy="18" r="2" fill="white"/>
    <circle cx="12" cy="34" r="3" fill="white"/>
    <circle cx="12" cy="44" r="3" fill="white" opacity="0.7"/>
    <path d="M24 34 V44 M32 34 V44" stroke="white" strokeWidth="1" opacity="0.4" strokeDasharray="3 3"/>
  </svg>
);
const NetworkIcon = () => (
  <svg width="68" height="68" viewBox="0 0 68 68" fill="none">
    <circle cx="20" cy="22" r="6" stroke="white" strokeWidth="1.5"/>
    <circle cx="48" cy="22" r="6" stroke="white" strokeWidth="1.5"/>
    <circle cx="34" cy="46" r="6" stroke="white" strokeWidth="1.5"/>
    <path d="M24 26 L30 42 M44 26 L38 42 M26 22 H42" stroke="white" strokeWidth="1.2" opacity="0.8"/>
    <circle cx="20" cy="22" r="2" fill="white"/>
    <circle cx="48" cy="22" r="2" fill="white"/>
    <circle cx="34" cy="46" r="2" fill="white"/>
    <path d="M16 38 Q34 32 52 38" stroke="white" strokeWidth="1" opacity="0.3" strokeDasharray="4 3"/>
  </svg>
);

// --- HERO PLATFORM ILLUSTRATION ---
const HeroPlatformSVG = () => (
  <svg viewBox="0 0 400 360" className="absolute inset-0 w-full h-full" preserveAspectRatio="xMidYMid slice">
    <defs>
      <linearGradient id="oceanGrad" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stopColor="#0A7AA5" stopOpacity="0.9"/>
        <stop offset="100%" stopColor="#052A42" stopOpacity="1"/>
      </linearGradient>
      <linearGradient id="platformMetal" x1="0" y1="0" x2="1" y2="0">
        <stop offset="0%" stopColor="#B8E8F2"/>
        <stop offset="100%" stopColor="#6DD3E8"/>
      </linearGradient>
      <filter id="glowC"><feGaussianBlur stdDeviation="3" result="coloredBlur"/><feMerge><feMergeNode in="coloredBlur"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
    </defs>
    
    {/* Ocean base */}
    <rect x="0" y="230" width="400" height="130" fill="url(#oceanGrad)"/>
    {/* Ocean waves - CSS like */}
    <path d="M0 240 Q50 235 100 240 T200 240 T300 242 T400 240" stroke="#24D6E8" strokeWidth="1.2" fill="none" opacity="0.6"/>
    <path d="M0 255 Q60 250 120 255 T240 255 T360 257 T400 255" stroke="white" strokeWidth="0.9" fill="none" opacity="0.35"/>
    <path d="M0 270 Q80 265 160 270 T320 270 T400 270" stroke="#24D6E8" strokeWidth="0.8" fill="none" opacity="0.35"/>

    {/* Legs */}
    <path d="M110 230 L95 330 M290 230 L305 330 M155 230 L150 330 M245 230 L250 330" stroke="#7FE5F2" strokeWidth="2.2" opacity="0.8" strokeLinecap="round"/>
    <path d="M110 260 L245 260 M95 290 L150 290 M250 290 L305 290" stroke="#7FE5F2" strokeWidth="1" opacity="0.5"/>

    {/* Main deck */}
    <rect x="90" y="200" width="220" height="18" rx="4" fill="url(#platformMetal)" stroke="white" strokeWidth="0.8" opacity="0.95"/>
    <rect x="100" y="205" width="200" height="3" rx="1.5" fill="white" opacity="0.6"/>

    {/* Topside modules */}
    <rect x="110" y="165" width="55" height="35" rx="4" fill="rgba(255,255,255,0.95)" stroke="#24D6E8" strokeWidth="1"/>
    <rect x="118" y="173" width="10" height="10" rx="2" fill="#073B5C" opacity="0.2"/>
    <rect x="132" y="173" width="10" height="10" rx="2" fill="#073B5C" opacity="0.2"/>
    <rect x="118" y="186" width="24" height="4" rx="1" fill="#087EAA" opacity="0.6"/>

    <rect x="185" y="155" width="45" height="45" rx="6" fill="rgba(255,255,255,0.9)" stroke="white" strokeWidth="1"/>
    <circle cx="207" cy="177" r="10" stroke="#087EAA" strokeWidth="1.2" opacity="0.5"/>
    <path d="M200 177 L214 177 M207 170 L207 184" stroke="#087EAA" strokeWidth="1"/>

    <rect x="250" y="168" width="40" height="32" rx="4" fill="rgba(255,255,255,0.85)"/>

    {/* Crane / flare */}
    <path d="M300 200 L320 120 L325 120 L305 200" fill="none" stroke="white" strokeWidth="1.5" opacity="0.8"/>
    <circle cx="322" cy="115" r="6" fill="#FFD86A" filter="url(#glowC)" opacity="0.9"/>
    <circle cx="322" cy="115" r="2.5" fill="white"/>

    {/* Lights */}
    <circle cx="115" cy="204" r="3" fill="#24D6E8" filter="url(#glowC)"/>
    <circle cx="200" cy="202" r="2.5" fill="#17BFA3" filter="url(#glowC)"/>
    <circle cx="285" cy="204" r="3" fill="#24D6E8" filter="url(#glowC)"/>

    {/* Small helicopter pad */}
    <circle cx="155" cy="145" r="12" stroke="white" strokeWidth="1" opacity="0.6" strokeDasharray="3 3"/>
    <path d="M148 145 L162 145 M155 138 L155 152" stroke="white" strokeWidth="1" opacity="0.8"/>

    {/* Signal dots */}
    <g opacity="0.9">
      <circle cx="60" cy="100" r="1.5" fill="white" opacity="0.5"/>
      <circle cx="340" cy="90" r="1.8" fill="#24D6E8" opacity="0.8"/>
      <circle cx="80" cy="80" r="1" fill="white" opacity="0.4"/>
      <circle cx="320" cy="200" r="1.2" fill="white" opacity="0.5"/>
    </g>

    {/* Top gradient vignette lines */}
    <path d="M0 50 L400 70" stroke="white" strokeWidth="0.5" opacity="0.08"/>
    <path d="M0 70 L400 90" stroke="white" strokeWidth="0.5" opacity="0.06"/>
  </svg>
);

const AboutVisualSVG = () => (
  <svg viewBox="0 0 200 160" className="w-full h-full">
    <defs>
      <linearGradient id="abGrad" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stopColor="#0A4A6B"/>
        <stop offset="100%" stopColor="#073B5C"/>
      </linearGradient>
      <radialGradient id="abGlow" cx="0.5" cy="0.3" r="0.7">
        <stop offset="0%" stopColor="#24D6E8" stopOpacity="0.25"/>
        <stop offset="100%" stopColor="#073B5C" stopOpacity="0"/>
      </radialGradient>
    </defs>
    <rect width="200" height="160" rx="20" fill="url(#abGrad)"/>
    <rect width="200" height="160" rx="20" fill="url(#abGlow)"/>
    {/* Abstract facility */}
    <g transform="translate(50,35)" opacity="0.95">
      <rect x="0" y="35" width="100" height="36" rx="6" fill="rgba(255,255,255,0.92)"/>
      <rect x="10" y="45" width="14" height="14" rx="2" fill="#087EAA" opacity="0.3"/>
      <rect x="30" y="45" width="14" height="14" rx="2" fill="#087EAA" opacity="0.2"/>
      <rect x="10" y="62" width="34" height="4" rx="2" fill="#073B5C" opacity="0.15"/>
      <path d="M15 35 V18 H25 V35 M40 35 V12 H50 V35 M65 35 V20 H75 V35" stroke="white" strokeWidth="2" strokeLinecap="round" opacity="0.9"/>
      <circle cx="20" cy="15" r="2.5" fill="#24D6E8"/>
      <circle cx="45" cy="9" r="2.5" fill="#17BFA3"/>
    </g>
    {/* dots grid */}
    <g opacity="0.2">
      {Array.from({length:6}).map((_,i)=>(
        <g key={i}>
          <circle cx={20 + i*30} cy={20} r="1" fill="white"/>
          <circle cx={20 + i*30} cy={140} r="1" fill="white"/>
        </g>
      ))}
    </g>
    <path d="M30 110 Q100 105 170 110" stroke="#24D6E8" strokeWidth="1" opacity="0.4" fill="none"/>
  </svg>
);

export default function App() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [showTop, setShowTop] = useState(false);
  const [form, setForm] = useState<Enquiry>({
    fullName: "",
    businessEmail: "",
    companyName: "",
    enquiryType: "General",
    message: "",
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);
  const [submitResult, setSubmitResult] = useState<{ type: "success" | "error"; text: string } | null>(null);
  const [enquiries, setEnquiries] = useState<StoredEnquiry[]>([]);
  const revealRefs = useRef<HTMLDivElement[]>([]);

  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > 20);
      setShowTop(window.scrollY > 600);
    };
    window.addEventListener("scroll", onScroll);
    onScroll();
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.title = "Pan Ocean Oil Corporation Nigeria Limited | Oil & Gas";
    const metaDesc = document.querySelector('meta[name="description"]');
    const content = "Learn about Pan Ocean Oil Corporation Nigeria Limited, its corporate profile, oil and gas industry focus, and contact information in Lagos, Nigeria.";
    if (metaDesc) metaDesc.setAttribute("content", content);
    else {
      const m = document.createElement("meta");
      m.name = "description";
      m.content = content;
      document.head.appendChild(m);
    }
  }, []);

  useEffect(() => {
    const obs = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) (e.target as HTMLElement).classList.add("is-visible");
        });
      },
      { threshold: 0.15 }
    );
    revealRefs.current.forEach((el) => el && obs.observe(el));
    return () => obs.disconnect();
  }, []);

  useEffect(() => {
    const load = async () => {
      try {
        const res = await fetch("actions", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ action: "records.list", args: { collection: "enquiries", limit: 20 } }),
        });
        const json = await res.json();
        if (json.data?.records) setEnquiries(json.data.records as StoredEnquiry[]);
      } catch {}
    };
    load();
  }, []);

  const scrollTo = (id: string) => {
    setMobileOpen(false);
    setTimeout(() => {
      document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
    }, 80);
  };

  const validate = () => {
    const e: Record<string, string> = {};
    if (!form.fullName.trim()) e.fullName = "Full name is required.";
    if (!form.businessEmail.trim()) e.businessEmail = "Business email is required.";
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.businessEmail)) e.businessEmail = "Enter a valid email address.";
    if (!form.message.trim()) e.message = "Please enter your message.";
    else if (form.message.trim().length < 10) e.message = "Message should be at least 10 characters.";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = async (ev: React.FormEvent) => {
    ev.preventDefault();
    setSubmitResult(null);
    if (!validate()) return;
    setSubmitting(true);
    try {
      const res = await fetch("actions", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          action: "records.create",
          args: {
            collection: "enquiries",
            value: { ...form, createdAt: new Date().toISOString() },
            idempotency_key: `${form.businessEmail}-${form.message.slice(0,20)}-${Date.now()}`,
          },
        }),
      });
      const json = await res.json();
      if (!res.ok || json.error) throw new Error(json.error || "Failed to save");
      const listRes = await fetch("actions", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ action: "records.list", args: { collection: "enquiries", limit: 20 } }),
      });
      const listJson = await listRes.json();
      if (listJson.data?.records) setEnquiries(listJson.data.records);
      setSubmitResult({
        type: "success",
        text: "Thank you. Your enquiry has been recorded securely. This is a demo implementation — in production, connect to a secure form service and corporate email routing.",
      });
      setForm({ fullName: "", businessEmail: "", companyName: "", enquiryType: "General", message: "" });
    } catch (err: any) {
      setSubmitResult({ type: "error", text: err.message || "Unable to save enquiry. Please try again." });
    } finally {
      setSubmitting(false);
    }
  };

  const focusCards = [
    { 
      title: "Oil & Gas Exploration", 
      desc: "Geological assessment, seismic interpretation, and prospect evaluation within Nigeria's basins.", 
      grad: "from-[#087EAA] to-[#24D6E8]",
      Icon: ExploreIcon
    },
    { 
      title: "Production and Operations", 
      desc: "Disciplined operations, facility integrity, and production optimization principles.", 
      grad: "from-[#073B5C] to-[#087EAA]",
      Icon: FactoryIcon
    },
    { 
      title: "Energy Infrastructure", 
      desc: "Pipeline systems, processing facilities, and logistical frameworks supporting energy delivery.", 
      grad: "from-[#17BFA3] to-[#24D6E8]",
      Icon: PipelineIcon
    },
    { 
      title: "Industry Partnerships", 
      desc: "Collaboration with service companies, technical partners, and regulatory stakeholders.", 
      grad: "from-[#073B5C] to-[#17BFA3]",
      Icon: NetworkIcon
    },
  ];

  return (
    <div
      data-safe-area-inset-root
      style={{ boxSizing: "border-box", paddingTop: "var(--safe-area-inset-top)", background: "var(--bg)" }}
      className="min-h-screen w-full font-[Manrope] text-[var(--text)] antialiased overflow-x-clip"
    >
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&family=Inter:wght@400;500;600&display=swap');
        :root{
          --deep:#073B5C; --petrol:#087EAA; --cyan:#24D6E8; --teal:#17BFA3;
          --white:#FFFFFF; --ice:#EAF8FC; --silver:#DCEAF0; --text:#123247;
          --bg:#FFFFFF;
        }
        *{font-family: 'Manrope', 'Inter', system-ui, sans-serif;}
        html{scroll-behavior:smooth;}
        .glass{background: rgba(255,255,255,0.78); backdrop-filter: blur(16px); -webkit-backdrop-filter: blur(16px); border:1px solid rgba(220,234,240,0.9);}
        .glass-dark{background: rgba(7,59,92,0.72); backdrop-filter: blur(16px); -webkit-backdrop-filter: blur(16px); border:1px solid rgba(255,255,255,0.15);}
        .glow-cyan{box-shadow: 0 0 0 1px rgba(36,214,232,0.18), 0 8px 40px rgba(36,214,232,0.35), 0 2px 10px rgba(8,126,170,0.15);}
        .glow-teal{box-shadow: 0 0 0 1px rgba(23,191,163,0.2), 0 8px 32px rgba(23,191,163,0.35);}
        .reveal{opacity:0; transform: translateY(24px); transition: all 0.8s cubic-bezier(0.16,1,0.3,1);}
        .reveal.is-visible{opacity:1; transform: translateY(0);}
        @keyframes gradientShift {
          0%{background-position:0% 50%;}
          50%{background-position:100% 50%;}
          100%{background-position:0% 50%;}
        }
        .animated-gradient{
          background-size: 200% 200%;
          animation: gradientShift 12s ease infinite;
        }
        @keyframes floatSlow {
          0%,100%{transform: translateY(0px);}
          50%{transform: translateY(-6px);}
        }
        .float-slow{animation: floatSlow 6s ease-in-out infinite;}
        .float-slow-delay{animation: floatSlow 6s ease-in-out infinite; animation-delay: -3s;}
        @media (prefers-reduced-motion: reduce){
          *, *::before, *::after{animation-duration:0.01ms !important; transition-duration:0.01ms !important; scroll-behavior:auto !important;}
          .reveal{opacity:1; transform:none;}
        }
      `}</style>

      {/* NAV */}
      <header
        data-safe-area-sticky-top
        style={{ top: "var(--safe-area-inset-top)" }}
        className={`sticky z-50 w-full border-b transition-all duration-500 ${
          scrolled ? "bg-white/95 backdrop-blur-xl shadow-[0_8px_30px_rgba(7,59,92,0.08)] border-[var(--silver)]" : "bg-white/70 backdrop-blur-md border-transparent"
        }`}
      >
        <div className="mx-auto max-w-[1280px] px-6 lg:px-8 h-[72px] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-xl bg-gradient-to-br from-[var(--ice)] to-white border border-[var(--silver)] flex items-center justify-center shadow-sm">
              <LOGO_SVG />
            </div>
            <div className="leading-none">
              <div className="font-extrabold tracking-[-0.02em] text-[18px] text-[var(--deep)]">PAN OCEAN</div>
              <div className="text-[10px] tracking-[0.18em] font-semibold text-[var(--petrol)] uppercase -mt-0.5">Oil Corporation</div>
            </div>
          </div>

          <nav className="hidden lg:flex items-center gap-8">
            {[
              { label: "Home", id: "home" },
              { label: "About Us", id: "about" },
              { label: "Our Focus", id: "focus" },
              { label: "Sustainability", id: "sustainability" },
              { label: "Insights", id: "insights" },
              { label: "Contact", id: "contact" },
            ].map((l) => (
              <button
                key={l.id}
                onClick={() => scrollTo(l.id)}
                className="text-[14px] font-medium text-[var(--text)]/80 hover:text-[var(--deep)] transition relative group py-2 focus-visible:outline focus-visible:outline-2 focus-visible:outline-[var(--cyan)]"
              >
                {l.label}
                <span className="absolute bottom-0 left-0 w-0 h-[2px] bg-gradient-to-r from-[var(--cyan)] to-[var(--teal)] group-hover:w-full transition-all duration-300 rounded-full" />
              </button>
            ))}
            <button
              onClick={() => scrollTo("contact")}
              className="ml-2 px-6 h-10 rounded-full bg-gradient-to-r from-[var(--cyan)] to-[var(--teal)] text-white font-semibold text-[14px] glow-cyan hover:brightness-[1.05] hover:-translate-y-[1px] active:translate-y-0 transition-all focus-visible:outline focus-visible:outline-2 focus-visible:outline-[var(--deep)]"
            >
              Contact Us
            </button>
          </nav>

          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            className="lg:hidden h-10 w-10 rounded-full border border-[var(--silver)] bg-white flex items-center justify-center focus-visible:outline focus-visible:outline-2 focus-visible:outline-[var(--cyan)]"
            aria-label="Menu"
          >
            <div className="space-y-1.5">
              <span className={`block h-0.5 w-5 bg-[var(--deep)] transition ${mobileOpen ? "rotate-45 translate-y-2" : ""}`} />
              <span className={`block h-0.5 w-5 bg-[var(--deep)] transition ${mobileOpen ? "opacity-0" : ""}`} />
              <span className={`block h-0.5 w-5 bg-[var(--deep)] transition ${mobileOpen ? "-rotate-45 -translate-y-2" : ""}`} />
            </div>
          </button>
        </div>

        <div
          className={`lg:hidden overflow-hidden transition-all duration-500 border-t border-[var(--silver)] bg-white ${mobileOpen ? "max-h-[420px] opacity-100" : "max-h-0 opacity-0"}`}
        >
          <div className="px-6 py-6 flex flex-col gap-1">
            {[
              { label: "Home", id: "home" },
              { label: "About Us", id: "about" },
              { label: "Our Focus", id: "focus" },
              { label: "Sustainability", id: "sustainability" },
              { label: "Insights", id: "insights" },
              { label: "Contact", id: "contact" },
            ].map((l) => (
              <button
                key={l.id}
                onClick={() => scrollTo(l.id)}
                className="text-left py-3 text-[16px] font-medium border-b border-[var(--silver)]/60 last:border-0 focus-visible:outline focus-visible:outline-2 focus-visible:outline-[var(--cyan)]"
              >
                {l.label}
              </button>
            ))}
            <button
              onClick={() => scrollTo("contact")}
              className="mt-4 h-12 rounded-full bg-gradient-to-r from-[var(--cyan)] to-[var(--teal)] text-white font-semibold glow-cyan"
            >
              Contact Us
            </button>
          </div>
        </div>
      </header>

      {/* HERO - 100% CSS+SVG, NO EXTERNAL IMAGES */}
      <section id="home" className="relative overflow-hidden bg-white">
        <div className="pointer-events-none absolute -top-20 left-1/2 -translate-x-1/2 w-[1200px] h-[600px] bg-[radial-gradient(ellipse_at_top,_rgba(36,214,232,0.12),transparent_60%)]" />
        <div className="pointer-events-none absolute top-40 -right-40 h-[500px] w-[500px] rounded-full bg-[radial-gradient(circle,_rgba(23,191,163,0.12),transparent_70%)] blur-[30px]" />
        <div className="mx-auto max-w-[1280px] px-6 lg:px-8 py-16 lg:py-28 grid lg:grid-cols-[1.05fr_0.95fr] gap-12 items-center">
          <div>
            <div className="reveal is-visible inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[var(--ice)] border border-[var(--silver)]">
              <span className="h-1.5 w-1.5 rounded-full bg-[var(--teal)] animate-pulse" />
              <span className="text-[11px] tracking-[0.18em] font-bold text-[var(--teal)] uppercase">Energy • Operations • Industrial Excellence</span>
            </div>

            <h1 className="reveal is-visible mt-8 text-[44px] lg:text-[72px] font-extrabold tracking-[-0.04em] leading-[0.9] text-[var(--deep)]">
              Powering
              <br />
              <span className="relative inline-block">
                <span className="bg-gradient-to-r from-[var(--petrol)] to-[var(--teal)] bg-clip-text text-transparent">Energy.</span>
                <span className="absolute -bottom-2 left-0 right-0 h-[6px] bg-gradient-to-r from-[var(--cyan)]/40 to-[var(--teal)]/40 blur-[4px] rounded-full" />
              </span>
              <br />
              Building
              <br />
              Tomorrow.
            </h1>
            <p className="reveal is-visible mt-8 text-[17px] leading-[1.7] text-[var(--text)]/70 max-w-[560px] font-[Inter]">
              Discover Pan Ocean Oil Corporation Nigeria Limited and its place in Nigeria's energy landscape. Explore our corporate profile, industry focus, and commitment to professional standards.
            </p>
            <div className="reveal is-visible mt-10 flex flex-wrap gap-4">
              <button
                onClick={() => scrollTo("about")}
                className="group h-[52px] px-8 rounded-full bg-gradient-to-r from-[var(--cyan)] to-[var(--teal)] text-white font-semibold text-[15px] glow-cyan flex items-center gap-2 hover:brightness-110 hover:-translate-y-0.5 transition-all focus-visible:outline focus-visible:outline-2 focus-visible:outline-[var(--deep)]"
              >
                Explore Our Company
                <span className="h-5 w-5 rounded-full bg-white/20 flex items-center justify-center group-hover:translate-x-0.5 transition-transform">→</span>
              </button>
              <button
                onClick={() => scrollTo("contact")}
                className="h-[52px] px-8 rounded-full bg-white border border-[var(--silver)] text-[var(--deep)] font-semibold text-[15px] hover:border-[var(--petrol)]/30 hover:bg-[var(--ice)] transition-all focus-visible:outline focus-visible:outline-2 focus-visible:outline-[var(--cyan)]"
              >
                Contact Our Team
              </button>
            </div>

            <div className="mt-14 flex items-center gap-6 reveal is-visible">
              <div className="flex -space-x-2">
                {["EO","NG","OP"].map((t,i)=>(
                  <div key={i} className="h-9 w-9 rounded-full border-2 border-white bg-gradient-to-br from-[var(--silver)] to-[var(--ice)] flex items-center justify-center text-[10px] font-bold text-[var(--petrol)]">
                    {t}
                  </div>
                ))}
              </div>
              <div className="text-[13px] leading-[1.4] text-[var(--text)]/60 font-[Inter]">
                <span className="font-semibold text-[var(--deep)]">Corporate presence</span> in Victoria Island,<br />Lagos, Nigeria.
              </div>
            </div>
          </div>

          {/* HERO VISUAL - PURE CSS+SVG - ALWAYS RENDERS */}
          <div className="relative lg:h-[640px] flex items-center justify-center">
            <div className="absolute inset-0 -z-10">
              <div className="absolute top-10 right-10 h-[260px] w-[260px] rounded-full bg-[radial-gradient(circle,rgba(36,214,232,0.5),transparent_70%)] blur-[40px]" />
              <div className="absolute bottom-10 left-10 h-[300px] w-[300px] rounded-full bg-[radial-gradient(circle,rgba(23,191,163,0.4),transparent_70%)] blur-[50px]" />
            </div>

            <div className="relative w-full max-w-[560px]">
              <div className="relative rounded-[32px] overflow-hidden bg-gradient-to-br from-[var(--deep)] via-[var(--petrol)] to-[var(--deep)] p-[1px]" style={{boxShadow: "0 0 0 1px rgba(36,214,232,0.2), 0 0 60px rgba(36,214,232,0.45), 0 20px 80px rgba(7,59,92,0.25)"}}>
                <div className="rounded-[31px] relative overflow-hidden aspect-[4/3.2] lg:aspect-[4/4.2] bg-[#041F33]">
                  {/* Base gradient layers */}
                  <div className="absolute inset-0 animated-gradient" style={{backgroundImage: "radial-gradient(ellipse at 20% 20%, rgba(36,214,232,0.35) 0%, transparent 50%), radial-gradient(ellipse at 80% 10%, rgba(23,191,163,0.3) 0%, transparent 45%), linear-gradient(160deg, #073B5C 0%, #0A5C85 35%, #0B7AA5 65%, #0E9BB8 100%)"}}/>
                  {/* Subtle grid */}
                  <div className="absolute inset-0 opacity-[0.08]" style={{backgroundImage: "linear-gradient(rgba(255,255,255,0.4) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.4) 1px, transparent 1px)", backgroundSize: "32px 32px"}}/>
                  
                  {/* Glow orbs */}
                  <div className="absolute -top-10 -right-10 h-[200px] w-[200px] rounded-full blur-[40px] bg-[rgba(36,214,232,0.5)]" />
                  <div className="absolute bottom-20 -left-20 h-[220px] w-[220px] rounded-full blur-[50px] bg-[rgba(23,191,163,0.4)]" />
                  <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 h-[300px] w-[300px] rounded-full blur-[80px] bg-[radial-gradient(circle,rgba(36,214,232,0.2),transparent_70%)]" />

                  {/* Platform SVG */}
                  <HeroPlatformSVG />

                  {/* Top highlight line */}
                  <div className="absolute top-0 left-6 right-6 h-[1px] bg-gradient-to-r from-transparent via-white/30 to-transparent" />
                  {/* Right cyan edge glow */}
                  <div className="absolute top-6 bottom-6 right-6 w-[4px] rounded-full bg-gradient-to-b from-[var(--cyan)] to-[var(--teal)] shadow-[0_0_20px_rgba(36,214,232,0.8)]" />

                  {/* Floating glass cards */}
                  <div className="absolute bottom-4 left-4 right-4 flex gap-3">
                    <div className="glass rounded-2xl px-4 py-3 flex-1 float-slow">
                      <div className="flex items-center gap-2">
                        <div className="h-6 w-6 rounded-full bg-gradient-to-br from-[var(--cyan)] to-[var(--teal)] flex items-center justify-center">
                          <div className="h-1.5 w-1.5 rounded-full bg-white animate-pulse"/>
                        </div>
                        <div className="text-[10px] uppercase tracking-[0.15em] font-bold text-[var(--petrol)]">Operations</div>
                      </div>
                      <div className="text-[13px] font-bold text-[var(--deep)] mt-1 leading-tight">Offshore Operations</div>
                      <div className="text-[11px] text-[var(--text)]/60 mt-0.5">Victoria Island • Lagos</div>
                    </div>
                    <div className="glass rounded-2xl px-4 py-3 flex-1 float-slow-delay">
                      <div className="flex items-center gap-2">
                        <div className="h-6 w-6 rounded-full bg-white border border-[var(--silver)] flex items-center justify-center text-[10px]">◍</div>
                        <div className="text-[10px] uppercase tracking-[0.15em] font-bold text-[var(--teal)]">Sector</div>
                      </div>
                      <div className="text-[13px] font-bold text-[var(--deep)] mt-1 leading-tight">Energy Infrastructure</div>
                      <div className="flex items-center gap-1 mt-1">
                        <span className="h-1 w-12 rounded-full bg-gradient-to-r from-[var(--cyan)] to-[var(--teal)]"/>
                        <span className="text-[10px] font-bold text-[var(--teal)]">LIVE</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Outer floating card - professional standards */}
              <div className="absolute -bottom-6 -left-6 lg:-left-10 glass rounded-[20px] p-3 shadow-[0_20px_60px_rgba(7,59,92,0.15)] max-w-[260px] hidden sm:flex gap-3 items-start float-slow">
                <div className="h-12 w-12 rounded-xl bg-gradient-to-br from-[#073B5C] to-[#087EAA] flex items-center justify-center text-white">
                  <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
                    <rect x="3" y="8" width="16" height="8" rx="2" stroke="white" strokeWidth="1.2"/>
                    <path d="M6 8 V5 H10 V8 M12 8 V4 H16 V8" stroke="white" strokeWidth="1.2"/>
                  </svg>
                </div>
                <div>
                  <div className="text-[12px] font-bold text-[var(--deep)] leading-tight">Professional standards & operational discipline</div>
                  <div className="text-[11px] text-[var(--text)]/60 mt-1 font-[Inter]">Industry focus areas presented for verification.</div>
                </div>
              </div>

              {/* Pulsing dot */}
              <div className="absolute -top-4 -right-4 h-16 w-16 rounded-full bg-white border border-[var(--silver)] shadow-[0_12px_30px_rgba(7,59,92,0.12)] flex items-center justify-center">
                <div className="h-10 w-10 rounded-full bg-gradient-to-br from-[var(--ice)] to-white border border-[var(--silver)] flex items-center justify-center relative">
                  <div className="h-2 w-2 rounded-full bg-[var(--teal)] animate-ping absolute" />
                  <div className="h-2 w-2 rounded-full bg-[var(--teal)] relative" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ABOUT - CSS+SVG ONLY */}
      <section id="about" className="relative bg-[var(--ice)]/50 border-y border-[var(--silver)]/50 overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-[var(--cyan)]/30 to-transparent" />
        <div className="mx-auto max-w-[1280px] px-6 lg:px-8 py-24 lg:py-32">
          <div
            ref={(el) => { if (el) revealRefs.current[0] = el; }}
            className="reveal grid lg:grid-cols-2 gap-16 items-start"
          >
            <div>
              <div className="inline-flex px-3 py-1 rounded-full bg-white border border-[var(--silver)] text-[11px] tracking-[0.18em] font-bold text-[var(--petrol)] uppercase">About The Company</div>
              <h2 className="mt-6 text-[34px] lg:text-[48px] font-extrabold tracking-[-0.03em] leading-[1.05] text-[var(--deep)]">
                An Energy Company with a Long-Term Perspective
              </h2>
              <p className="mt-6 text-[16px] leading-[1.8] text-[var(--text)]/70 font-[Inter] max-w-[560px]">
                Pan Ocean Oil Corporation Nigeria Limited operates within Nigeria's oil and gas industry. This corporate website provides an introduction to the company, its business focus, and the information visitors need to learn more and make contact.
              </p>
              <div className="mt-8 p-5 rounded-2xl bg-white border border-[var(--silver)] shadow-sm">
                <div className="flex gap-3">
                  <div className="h-9 w-9 rounded-full bg-[var(--ice)] border border-[var(--silver)] flex items-center justify-center text-[var(--petrol)]">⌖</div>
                  <div>
                    <div className="text-[14px] font-bold text-[var(--deep)]">Verified Information Only</div>
                    <div className="text-[13px] text-[var(--text)]/60 mt-1 font-[Inter] leading-relaxed">
                      We do not publish founding year, executive team, history, operational sites, reserves, or ownership information without independent verification. This site focuses on corporate credibility.
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="relative">
              <div className="relative rounded-[28px] overflow-hidden bg-gradient-to-br from-[var(--silver)] to-white p-[1px] shadow-[0_20px_60px_rgba(7,59,92,0.1)]">
                <div className="rounded-[27px] bg-white overflow-hidden">
                  <div className="aspect-[4/3] relative overflow-hidden">
                    <div className="absolute inset-0" style={{background: "radial-gradient(ellipse at 30% 20%, rgba(36,214,232,0.35) 0%, transparent 55%), linear-gradient(135deg, #073B5C 0%, #0A5F87 45%, #17BFA3 100%)"}}/>
                    <div className="absolute inset-0 opacity-30" style={{backgroundImage: "radial-gradient(circle at 1px 1px, white 1px, transparent 0)", backgroundSize: "22px 22px"}}/>
                    <AboutVisualSVG />
                    <div className="absolute inset-0 bg-gradient-to-t from-[rgba(7,59,92,0.55)] via-transparent to-transparent" />
                    
                    {/* Floating labels */}
                    <div className="absolute bottom-4 left-4 right-4 flex justify-between items-end">
                      <div className="glass rounded-xl px-3 py-2 text-[11px] font-bold text-[var(--deep)] flex items-center gap-2">
                        <span className="h-2 w-2 rounded-full bg-[var(--teal)] animate-pulse"/>
                        Corporate Profile • Lagos, NG
                      </div>
                      <div className="glass-dark rounded-full px-3 py-1.5 text-[10px] font-bold tracking-widest uppercase text-white">Professional Standards</div>
                    </div>

                    {/* Center badge */}
                    <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none">
                      <div className="h-20 w-20 rounded-full bg-white/10 backdrop-blur border border-white/20 flex items-center justify-center shadow-[0_0_30px_rgba(36,214,232,0.4)]">
                        <div className="text-center">
                          <div className="text-[20px] font-extrabold text-white">PS</div>
                          <div className="text-[7px] tracking-[0.2em] font-bold text-white/70 uppercase">Verified</div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="p-5 flex items-center justify-between bg-white">
                    <div className="text-[13px] font-[Inter] text-[var(--text)]/60 flex items-center gap-2">
                      <span className="h-5 w-5 rounded-full bg-[var(--ice)] border border-[var(--silver)] flex items-center justify-center text-[10px]">✦</span>
                      100% CSS • No external image dependencies
                    </div>
                    <div className="h-8 w-8 rounded-full bg-[var(--ice)] border border-[var(--silver)] flex items-center justify-center text-[var(--petrol)]">◐</div>
                  </div>
                </div>
              </div>
              <div className="absolute -z-10 -bottom-8 -right-8 h-[200px] w-[200px] rounded-full bg-[radial-gradient(circle,rgba(36,214,232,0.25),transparent_70%)] blur-[20px]" />
            </div>
          </div>

          <div className="mt-16 grid md:grid-cols-3 gap-6">
            {[
              { title: "Corporate Profile", desc: "An introduction to the company's identity and industry context, presented with verified information only.", icon: "◧" },
              { title: "Energy Industry Focus", desc: "An overview of oil and natural gas business focus, with specific activities included only after verification.", icon: "◍" },
              { title: "Professional Standards", desc: "Communicating verified corporate policies, operational principles, and published standards when available.", icon: "✦" },
            ].map((c, i) => (
              <div
                key={c.title}
                ref={(el) => { if (el) revealRefs.current[1 + i] = el; }}
                className="reveal glass rounded-[20px] p-7 hover:-translate-y-1 hover:shadow-[0_20px_40px_rgba(7,59,92,0.08)] transition-all duration-500"
              >
                <div className="h-12 w-12 rounded-2xl bg-gradient-to-br from-white to-[var(--ice)] border border-[var(--silver)] flex items-center justify-center text-[var(--petrol)] text-[18px] shadow-sm">
                  {c.icon}
                </div>
                <h3 className="mt-5 text-[18px] font-bold tracking-[-0.01em] text-[var(--deep)]">{c.title}</h3>
                <p className="mt-3 text-[14px] leading-[1.7] text-[var(--text)]/65 font-[Inter]">{c.desc}</p>
                <div className="mt-6 h-[3px] w-12 rounded-full bg-gradient-to-r from-[var(--cyan)] to-[var(--teal)]" />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* OUR FOCUS - PURE CSS GRADIENT HEADERS */}
      <section id="focus" className="bg-white relative overflow-hidden py-24 lg:py-32">
        <div className="mx-auto max-w-[1280px] px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6">
            <div>
              <div className="inline-flex px-3 py-1 rounded-full bg-[var(--ice)] border border-[var(--silver)] text-[11px] tracking-[0.18em] font-bold text-[var(--petrol)] uppercase">Our Business Focus</div>
              <h2 className="mt-4 text-[34px] lg:text-[48px] font-extrabold tracking-[-0.03em] leading-[1.05] text-[var(--deep)]">
                Informational overview
                <br />
                <span className="text-[var(--text)]/40">of industry areas</span>
              </h2>
            </div>
            <div className="max-w-[360px] text-[14px] leading-[1.7] text-[var(--text)]/60 font-[Inter]">
              Presented as industry focus areas pending verification. We do not imply operation of specific assets without reliable evidence.
            </div>
          </div>

          <div className="mt-14 grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {focusCards.map((card, idx) => (
              <div
                key={card.title}
                ref={(el) => { if (el) revealRefs.current[4 + idx] = el; }}
                className="reveal group relative rounded-[20px] bg-white border border-[var(--silver)] overflow-hidden hover:-translate-y-1 hover:shadow-[0_20px_50px_rgba(7,59,92,0.1)] hover:border-[var(--cyan)]/30 transition-all duration-500 flex flex-col"
              >
                <div className={`h-[180px] relative overflow-hidden bg-gradient-to-br ${card.grad} flex items-center justify-center`}>
                  {/* Pattern overlay */}
                  <div className="absolute inset-0 opacity-20" style={{backgroundImage: "radial-gradient(circle at 2px 2px, white 1.5px, transparent 0)", backgroundSize: "20px 20px"}}/>
                  <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_rgba(255,255,255,0.25),transparent_60%)]"/>
                  <div className="absolute top-3 left-3 px-2.5 py-1 rounded-full bg-white/90 backdrop-blur border border-white text-[10px] font-bold tracking-[0.12em] uppercase text-[var(--petrol)]">
                    0{idx + 1} • Focus
                  </div>
                  {/* Glow */}
                  <div className="absolute bottom-0 left-1/2 -translate-x-1/2 h-[80px] w-[140px] rounded-full blur-[30px] bg-white/20"/>
                  <div className="relative z-10 group-hover:scale-110 transition-transform duration-500">
                    <card.Icon />
                  </div>
                  {/* Bottom fade */}
                  <div className="absolute bottom-0 left-0 right-0 h-[40px] bg-gradient-to-t from-black/15 to-transparent"/>
                </div>
                <div className="p-6 flex-1 flex flex-col">
                  <h3 className="text-[16px] font-bold text-[var(--deep)] leading-tight">{card.title}</h3>
                  <p className="mt-3 text-[13px] leading-[1.6] text-[var(--text)]/60 font-[Inter] flex-1">{card.desc}</p>
                  <div className="mt-5 flex items-center gap-2 text-[12px] font-semibold text-[var(--petrol)]">
                    <span>Industry overview</span>
                    <span className="group-hover:translate-x-1 transition-transform">→</span>
                  </div>
                </div>
                <div className="absolute bottom-0 left-6 right-6 h-[3px] rounded-full bg-gradient-to-r from-[var(--cyan)]/0 via-[var(--cyan)]/50 to-[var(--teal)]/0 opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
            ))}
          </div>

          <div className="mt-10 flex justify-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[var(--ice)] border border-[var(--silver)] text-[11px] text-[var(--text)]/60 font-[Inter]">
              <span className="h-1.5 w-1.5 rounded-full bg-[var(--teal)]" />
              Presented as industry focus areas pending verification — 100% CSS visuals.
            </div>
          </div>
        </div>
      </section>

      {/* ENERGY INFRASTRUCTURE IN FOCUS - PURE CSS+SVG BACKGROUND */}
      <section className="relative overflow-hidden">
        <div className="relative bg-[var(--deep)]">
          <div className="absolute inset-0">
            {/* Base gradients - no external image */}
            <div className="absolute inset-0" style={{background: "linear-gradient(90deg, rgba(7,59,92,0.98) 0%, rgba(7,59,92,0.92) 40%, rgba(8,126,170,0.85) 75%, rgba(23,191,163,0.55) 100%)"}}/>
            <div className="absolute inset-0 opacity-60" style={{background: "radial-gradient(ellipse at 30% 50%, rgba(36,214,232,0.25) 0%, transparent 60%), radial-gradient(ellipse at 80% 20%, rgba(23,191,163,0.2) 0%, transparent 50%)"}}/>
            
            {/* SVG Infrastructure Pattern */}
            <svg className="absolute inset-0 w-full h-full opacity-[0.18]" viewBox="0 0 1200 600" preserveAspectRatio="xMidYMid slice">
              <defs>
                <pattern id="infraGrid" width="80" height="80" patternUnits="userSpaceOnUse">
                  <circle cx="40" cy="40" r="1.2" fill="white"/>
                  <path d="M0 40 H80 M40 0 V80" stroke="white" strokeWidth="0.3" opacity="0.3"/>
                </pattern>
              </defs>
              <rect width="1200" height="600" fill="url(#infraGrid)"/>
              {/* Abstract pipeline network */}
              <path d="M0 280 Q200 270 400 300 T800 290 T1200 280" stroke="#24D6E8" strokeWidth="1.5" fill="none" opacity="0.6"/>
              <path d="M0 340 Q300 330 600 360 T1200 340" stroke="white" strokeWidth="1" fill="none" opacity="0.4"/>
              <path d="M100 0 V600 M300 0 V600 M600 0 V600 M900 0 V600" stroke="white" strokeWidth="0.5" opacity="0.08" strokeDasharray="8 8"/>
              {/* Nodes */}
              <g>
                <circle cx="200" cy="285" r="6" fill="none" stroke="#24D6E8" strokeWidth="1.2"/>
                <circle cx="200" cy="285" r="2" fill="#24D6E8"/>
                <circle cx="600" cy="355" r="8" fill="none" stroke="white" strokeWidth="1" opacity="0.6"/>
                <circle cx="600" cy="355" r="3" fill="white"/>
                <circle cx="950" cy="295" r="5" fill="none" stroke="#17BFA3" strokeWidth="1.2"/>
                <circle cx="950" cy="295" r="2" fill="#17BFA3"/>
              </g>
              {/* Flow dots animation hint */}
              <circle cx="350" cy="295" r="2.5" fill="white" opacity="0.8">
                <animate attributeName="opacity" values="0.2;1;0.2" dur="2s" repeatCount="indefinite"/>
              </circle>
            </svg>

            {/* Additional glow */}
            <div className="absolute top-1/2 left-1/4 h-[400px] w-[400px] rounded-full blur-[80px] bg-[rgba(36,214,232,0.15)]" />
            <div className="absolute bottom-0 right-1/4 h-[300px] w-[300px] rounded-full blur-[60px] bg-[rgba(23,191,163,0.12)]" />
          </div>

          <div className="relative z-20 mx-auto max-w-[1280px] px-6 lg:px-8 py-24 lg:py-36">
            <div className="max-w-[760px]">
              <div className="flex items-center gap-4">
                <div className="h-[56px] w-[4px] rounded-full bg-gradient-to-b from-[var(--cyan)] to-[var(--teal)] shadow-[0_0_20px_rgba(36,214,232,0.6)]" />
                <div className="px-3 py-1 rounded-full bg-white/10 border border-white/20 text-[11px] tracking-[0.18em] font-bold text-[var(--cyan)] uppercase backdrop-blur">
                  Energy Infrastructure in Focus
                </div>
              </div>

              <h2 className="mt-8 text-[36px] lg:text-[56px] font-extrabold tracking-[-0.03em] leading-[1.02] text-white">
                Reliable energy
                <br />
                infrastructure demands
                <br />
                <span className="text-[var(--cyan)]">professional standards.</span>
              </h2>
              <p className="mt-6 text-[16px] leading-[1.7] text-white/70 max-w-[560px] font-[Inter]">
                The energy sector relies on robust infrastructure, disciplined operations, and rigorous safety culture. This section highlights the importance of professional operating standards — distinct from any unverified company-specific claims.
              </p>
              <p className="mt-4 text-[12px] leading-[1.6] text-white/50 font-[Inter] max-w-[520px] flex items-center gap-2">
                <span className="h-px w-6 bg-white/20"/>
                100% CSS • SVG infrastructure pattern • Zero external image dependencies • Always renders
              </p>

              <div className="mt-10 flex flex-wrap gap-4">
                <button
                  onClick={() => scrollTo("about")}
                  className="h-[48px] px-7 rounded-full bg-white text-[var(--deep)] font-semibold text-[14px] hover:bg-[var(--ice)] transition focus-visible:outline focus-visible:outline-2 focus-visible:outline-[var(--cyan)]"
                >
                  Discover Our Corporate Profile
                </button>
                <div className="flex items-center gap-3 px-4 h-[48px] rounded-full bg-white/10 border border-white/15 backdrop-blur text-[13px] text-white/80">
                  <span className="h-2 w-2 rounded-full bg-[var(--teal)] animate-pulse" />
                  Victoria Island • Lagos • Nigeria
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* RESPONSIBILITY */}
      <section id="sustainability" className="relative bg-[var(--ice)] overflow-hidden py-24 lg:py-32">
        <div className="pointer-events-none absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[800px] bg-[radial-gradient(circle,_rgba(36,214,232,0.12),transparent_60%)]" />
        <div className="mx-auto max-w-[1280px] px-6 lg:px-8 relative">
          <div className="max-w-[720px] mx-auto text-center">
            <div className="inline-flex px-3 py-1 rounded-full bg-white border border-[var(--silver)] text-[11px] tracking-[0.18em] font-bold text-[var(--teal)] uppercase">Responsibility in Energy</div>
            <h2 className="mt-6 text-[32px] lg:text-[48px] font-extrabold tracking-[-0.03em] leading-[1.05] text-[var(--deep)]">Responsibility in Energy</h2>
            <p className="mt-5 text-[15px] leading-[1.7] text-[var(--text)]/60 font-[Inter] max-w-[560px] mx-auto">
              Safety, environmental stewardship, and community engagement are foundational in the energy industry. Below are general industry principles. Company-specific commitments appear only when supported by verified information.
            </p>
          </div>

          <div className="mt-16 grid md:grid-cols-3 gap-8">
            {[
              { title: "Safety and Operational Discipline", desc: "Structured safety management, hazard identification, and continuous learning are essential to responsible operations. Verified company safety policies will be published here when confirmed.", icon: "⛨" },
              { title: "Environmental Responsibility", desc: "Minimizing environmental impact, responsible resource management, and compliance with regulatory frameworks. Environmental performance data only when verified.", icon: "◍" },
              { title: "People and Community", desc: "Workforce welfare, skills development, and respectful community engagement. Specific initiatives and community programs will be listed upon verification.", icon: "◎" },
            ].map((p, i) => (
              <div
                key={p.title}
                ref={(el) => { if (el) revealRefs.current[8 + i] = el; }}
                className="reveal relative bg-white rounded-[24px] border border-[var(--silver)] p-8 hover:shadow-[0_20px_60px_rgba(7,59,92,0.08)] hover:-translate-y-1 transition-all duration-500"
              >
                <div className="h-12 w-12 rounded-2xl bg-gradient-to-br from-[var(--ice)] to-white border border-[var(--silver)] flex items-center justify-center text-[var(--teal)] text-[18px]"> {p.icon} </div>
                <h3 className="mt-6 text-[18px] font-bold text-[var(--deep)] leading-tight">{p.title}</h3>
                <p className="mt-4 text-[14px] leading-[1.7] text-[var(--text)]/60 font-[Inter]">{p.desc}</p>
                <div className="mt-6 inline-flex px-3 py-1 rounded-full bg-[var(--ice)] border border-[var(--silver)] text-[10px] font-bold uppercase tracking-[0.12em] text-[var(--petrol)]">Industry Principle</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* INSIGHTS - GRADIENT HEADERS, NO IMAGES */}
      <section id="insights" className="bg-white py-24 lg:py-32 relative overflow-hidden border-t border-[var(--silver)]/50">
        <div className="mx-auto max-w-[1280px] px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row justify-between gap-6 items-start lg:items-end">
            <div>
              <div className="inline-flex px-3 py-1 rounded-full bg-[var(--ice)] border border-[var(--silver)] text-[11px] tracking-[0.18em] font-bold text-[var(--petrol)] uppercase">Corporate Insights</div>
              <h2 className="mt-4 text-[32px] lg:text-[44px] font-extrabold tracking-[-0.03em] text-[var(--deep)]">Corporate Insights</h2>
              <p className="mt-3 text-[14px] leading-[1.6] text-[var(--text)]/60 font-[Inter] max-w-[420px]">Future announcements, publications, and industry perspectives will appear here. Sample cards below are placeholders.</p>
            </div>
            <div className="px-4 py-2 rounded-full bg-[var(--ice)] border border-[var(--silver)] text-[12px] font-[Inter] text-[var(--text)]/60">Corporate updates and publications will be available here.</div>
          </div>

          <div className="mt-14 grid md:grid-cols-3 gap-6">
            {[
              { cat: "Industry", title: "Understanding Nigeria's Energy Landscape", summary: "An overview of Nigeria's oil and gas sector, regulatory context, and the importance of verified corporate information.", grad: "from-[#087EAA] via-[#0B8FC0] to-[#24D6E8]", accent: "bg-[#087EAA]" },
              { cat: "Corporate", title: "Professional Standards in Energy Operations", summary: "Why safety culture, operational discipline, and transparent reporting matter for energy companies.", grad: "from-[#073B5C] via-[#0A5A82] to-[#17BFA3]", accent: "bg-[#17BFA3]" },
              { cat: "Insights", title: "Energy Infrastructure and Community", summary: "How infrastructure development intersects with environmental responsibility and community engagement.", grad: "from-[#0A6B8A] to-[#24D6E8]", accent: "bg-[#24D6E8]" },
            ].map((art, i) => (
              <div
                key={art.title}
                className="group rounded-[20px] border border-[var(--silver)] overflow-hidden hover:-translate-y-1 hover:shadow-[0_20px_40px_rgba(7,59,92,0.08)] transition-all duration-500 bg-white flex flex-col"
              >
                <div className={`h-[180px] bg-gradient-to-br ${art.grad} relative overflow-hidden flex items-center justify-center`}>
                  <div className="absolute inset-0 opacity-25" style={{backgroundImage: "radial-gradient(circle at 1px 1px, white 1px, transparent 0)", backgroundSize: "18px 18px"}}/>
                  <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_rgba(255,255,255,0.25),transparent_60%)]"/>
                  <div className="absolute top-3 left-3 px-2.5 py-1 rounded-full bg-white/90 backdrop-blur border border-white text-[10px] font-bold tracking-[0.12em] uppercase text-[var(--petrol)]">
                    {art.cat}
                  </div>
                  <div className="relative h-16 w-16 rounded-2xl bg-white/15 backdrop-blur border border-white/20 flex items-center justify-center text-white font-bold text-[24px] group-hover:scale-105 transition-transform shadow-[0_8px_20px_rgba(0,0,0,0.15)]">
                    {i + 1}
                    <div className="absolute -bottom-1 -right-1 h-3 w-3 rounded-full bg-white shadow-sm border border-[var(--silver)]"/>
                  </div>
                  {/* Decorative line */}
                  <div className="absolute bottom-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-white/40 to-transparent"/>
                </div>
                <div className="p-6 flex-1 flex flex-col">
                  <h3 className="text-[16px] font-bold leading-[1.35] text-[var(--deep)]">{art.title}</h3>
                  <p className="mt-3 text-[13px] leading-[1.6] text-[var(--text)]/60 font-[Inter] flex-1">{art.summary}</p>
                  <button className="mt-5 inline-flex items-center gap-1.5 text-[13px] font-semibold text-[var(--petrol)] group-hover:gap-2.5 transition-all">
                    Read More <span>→</span>
                  </button>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-12 rounded-[20px] bg-[var(--ice)] border border-[var(--silver)] p-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="text-[13px] text-[var(--text)]/70 font-[Inter]">
              <span className="font-semibold text-[var(--deep)]">Empty state:</span> No verified press releases or publications yet. This component is ready for genuine content without redesign.
            </div>
            <div className="text-[11px] px-3 py-1 rounded-full bg-white border border-[var(--silver)] font-bold tracking-[0.12em] uppercase text-[var(--petrol)]">CMS Ready • 100% CSS</div>
          </div>
        </div>
      </section>

      {/* CONTACT */}
      <section id="contact" className="relative bg-[var(--ice)] overflow-hidden py-24 lg:py-32 border-t border-[var(--silver)]">
        <div className="pointer-events-none absolute -top-40 -right-40 h-[600px] w-[600px] rounded-full bg-[radial-gradient(circle,rgba(36,214,232,0.18),transparent_65%)]" />
        <div className="pointer-events-none absolute -bottom-40 -left-40 h-[600px] w-[600px] rounded-full bg-[radial-gradient(circle,rgba(23,191,163,0.14),transparent_65%)]" />

        <div className="mx-auto max-w-[1280px] px-6 lg:px-8 relative">
          <div className="grid lg:grid-cols-[0.9fr_1.1fr] gap-14 items-start">
            <div>
              <div className="inline-flex px-3 py-1 rounded-full bg-white border border-[var(--silver)] text-[11px] tracking-[0.18em] font-bold text-[var(--teal)] uppercase">Let's Connect</div>
              <h2 className="mt-5 text-[36px] lg:text-[52px] font-extrabold tracking-[-0.03em] leading-[0.95] text-[var(--deep)]">
                Let's
                <br />
                Connect
              </h2>
              <p className="mt-6 text-[15px] leading-[1.7] text-[var(--text)]/60 font-[Inter] max-w-[420px]">
                For corporate enquiries and general information, please contact Pan Ocean Oil Corporation Nigeria Limited through its verified communication channels.
              </p>

              <div className="mt-10 space-y-6">
                <div className="rounded-[20px] bg-white border border-[var(--silver)] p-6 shadow-sm">
                  <div className="text-[11px] uppercase tracking-[0.15em] font-bold text-[var(--petrol)]">Company</div>
                  <div className="mt-2 text-[15px] font-bold text-[var(--deep)]">Pan Ocean Oil Corporation Nigeria Limited</div>
                  <div className="mt-5 text-[11px] uppercase tracking-[0.15em] font-bold text-[var(--petrol)]">Address</div>
                  <div className="mt-2 text-[14px] leading-[1.6] text-[var(--text)]/70 font-[Inter]">
                    Plot 13/14, The Ark Towers, Ligali Ayorinde Street, behind Afribank Headquarters, Victoria Island, Lagos, Nigeria.
                  </div>
                  <div className="mt-5 text-[11px] uppercase tracking-[0.15em] font-bold text-[var(--petrol)]">Telephone</div>
                  <div className="mt-2 inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-amber-50 border border-amber-200 text-[12px] font-medium text-amber-700">
                    <span className="h-1.5 w-1.5 rounded-full bg-amber-500" />
                    Listing shows 13613000 — unverified, not clickable
                  </div>
                </div>

                <a
                  href="https://www.google.com/maps/search/?api=1&query=Plot+13+14+The+Ark+Towers+Ligali+Ayorinde+Victoria+Island+Lagos+Nigeria"
                  target="_blank"
                  rel="noopener"
                  className="inline-flex h-12 px-6 rounded-full bg-white border border-[var(--silver)] items-center gap-2 text-[14px] font-semibold text-[var(--deep)] hover:border-[var(--petrol)]/30 hover:bg-[var(--ice)] transition focus-visible:outline focus-visible:outline-2 focus-visible:outline-[var(--cyan)]"
                >
                  <span className="h-6 w-6 rounded-full bg-[var(--ice)] border border-[var(--silver)] flex items-center justify-center text-[12px]">↗</span>
                  Open in Google Maps
                </a>

                {enquiries.length > 0 && (
                  <div className="rounded-[16px] bg-white/70 border border-[var(--silver)] p-4">
                    <div className="text-[11px] uppercase tracking-[0.12em] font-bold text-[var(--petrol)]">Recent enquiries stored</div>
                    <div className="mt-3 space-y-2 max-h-[160px] overflow-auto pr-1">
                      {enquiries.slice(0,5).map((enq) => (
                        <div key={enq.id} className="text-[12px] font-[Inter] text-[var(--text)]/70 border-b border-[var(--silver)]/60 pb-2 last:border-0">
                          <span className="font-semibold text-[var(--deep)]">{enq.value.fullName}</span> • {enq.value.enquiryType} • {new Date(enq.value.createdAt).toLocaleDateString()}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>

            <div className="relative">
              <div className="rounded-[28px] bg-white border border-[var(--silver)] shadow-[0_30px_80px_rgba(7,59,92,0.12)] overflow-hidden">
                <div className="h-[6px] w-full bg-gradient-to-r from-[var(--cyan)] to-[var(--teal)]" />
                <form onSubmit={handleSubmit} className="p-8 lg:p-10 space-y-6" noValidate>
                  <div>
                    <h3 className="text-[20px] font-bold tracking-[-0.01em] text-[var(--deep)]">Corporate Enquiry</h3>
                    <p className="mt-2 text-[13px] leading-[1.6] text-[var(--text)]/60 font-[Inter]">Validated form with secure storage via records API.</p>
                  </div>

                  <div className="grid sm:grid-cols-2 gap-5">
                    <div>
                      <label className="text-[11px] tracking-[0.12em] font-bold uppercase text-[var(--petrol)]">Full Name *</label>
                      <input
                        value={form.fullName}
                        onChange={(e) => setForm({ ...form, fullName: e.target.value })}
                        className={`mt-2 w-full h-12 rounded-full border px-4 text-[14px] font-[Inter] outline-none transition focus:ring-2 focus:ring-[var(--cyan)]/30 ${errors.fullName ? "border-red-300 bg-red-50/50" : "border-[var(--silver)] bg-white focus:border-[var(--petrol)]/30"}`}
                        placeholder="John Doe"
                      />
                      {errors.fullName && <div className="mt-1 text-[11px] text-red-600">{errors.fullName}</div>}
                    </div>
                    <div>
                      <label className="text-[11px] tracking-[0.12em] font-bold uppercase text-[var(--petrol)]">Business Email *</label>
                      <input
                        value={form.businessEmail}
                        onChange={(e) => setForm({ ...form, businessEmail: e.target.value })}
                        className={`mt-2 w-full h-12 rounded-full border px-4 text-[14px] font-[Inter] outline-none transition focus:ring-2 focus:ring-[var(--cyan)]/30 ${errors.businessEmail ? "border-red-300 bg-red-50/50" : "border-[var(--silver)] bg-white focus:border-[var(--petrol)]/30"}`}
                        placeholder="name@company.com"
                        type="email"
                      />
                      {errors.businessEmail && <div className="mt-1 text-[11px] text-red-600">{errors.businessEmail}</div>}
                    </div>
                  </div>

                  <div className="grid sm:grid-cols-2 gap-5">
                    <div>
                      <label className="text-[11px] tracking-[0.12em] font-bold uppercase text-[var(--petrol)]">Company Name</label>
                      <input
                        value={form.companyName}
                        onChange={(e) => setForm({ ...form, companyName: e.target.value })}
                        className="mt-2 w-full h-12 rounded-full border border-[var(--silver)] px-4 text-[14px] font-[Inter] bg-white outline-none focus:border-[var(--petrol)]/30 focus:ring-2 focus:ring-[var(--cyan)]/30 transition"
                        placeholder="Optional"
                      />
                    </div>
                    <div>
                      <label className="text-[11px] tracking-[0.12em] font-bold uppercase text-[var(--petrol)]">Enquiry Type</label>
                      <select
                        value={form.enquiryType}
                        onChange={(e) => setForm({ ...form, enquiryType: e.target.value })}
                        className="mt-2 w-full h-12 rounded-full border border-[var(--silver)] px-4 text-[14px] font-[Inter] bg-white outline-none focus:border-[var(--petrol)]/30 transition"
                      >
                        <option>General</option>
                        <option>Partnership</option>
                        <option>Media</option>
                        <option>Careers</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="text-[11px] tracking-[0.12em] font-bold uppercase text-[var(--petrol)]">Message *</label>
                    <textarea
                      value={form.message}
                      onChange={(e) => setForm({ ...form, message: e.target.value })}
                      className={`mt-2 w-full min-h-[120px] rounded-[20px] border px-4 py-3 text-[14px] font-[Inter] leading-[1.6] outline-none resize-none transition focus:ring-2 focus:ring-[var(--cyan)]/30 ${errors.message ? "border-red-300 bg-red-50/50" : "border-[var(--silver)] bg-white focus:border-[var(--petrol)]/30"}`}
                      placeholder="How can we help?"
                    />
                    {errors.message && <div className="mt-1 text-[11px] text-red-600">{errors.message}</div>}
                  </div>

                  <button
                    type="submit"
                    disabled={submitting}
                    className="w-full h-[52px] rounded-full bg-gradient-to-r from-[var(--cyan)] to-[var(--teal)] text-white font-semibold text-[15px] glow-cyan hover:brightness-105 disabled:opacity-60 transition-all focus-visible:outline focus-visible:outline-2 focus-visible:outline-[var(--deep)]"
                  >
                    {submitting ? "Saving enquiry..." : "Submit Enquiry"}
                  </button>

                  {submitResult && (
                    <div
                      className={`rounded-2xl p-4 text-[13px] leading-[1.6] font-[Inter] border ${
                        submitResult.type === "success" ? "bg-emerald-50 border-emerald-200 text-emerald-800" : "bg-red-50 border-red-200 text-red-700"
                      }`}
                    >
                      {submitResult.text}
                    </div>
                  )}

                  <div className="text-[11px] leading-[1.5] text-[var(--text)]/50 font-[Inter] text-center">
                    This is a demo form. In production, connect to a secure form-processing service with spam protection, email routing, and data retention policy. No fake success is shown until validation passes.
                  </div>
                </form>
              </div>

              <div className="absolute -z-10 -bottom-10 -right-10 h-[300px] w-[300px] rounded-full bg-[radial-gradient(circle,rgba(36,214,232,0.22),transparent_65%)] blur-[20px]" />
            </div>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="relative bg-[var(--deep)] overflow-hidden">
        <div className="pointer-events-none absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-[var(--cyan)]/40 to-transparent" />
        <div className="pointer-events-none absolute -top-20 -left-20 h-[400px] w-[400px] rounded-full bg-[radial-gradient(circle,rgba(36,214,232,0.15),transparent_70%)]" />
        <div className="pointer-events-none absolute -bottom-40 right-0 h-[500px] w-[500px] rounded-full bg-[radial-gradient(circle,rgba(23,191,163,0.12),transparent_70%)]" />

        <div className="relative mx-auto max-w-[1280px] px-6 lg:px-8 py-16 lg:py-20">
          <div className="grid lg:grid-cols-[1.3fr_0.7fr_0.8fr_0.7fr] gap-12">
            <div>
              <div className="flex items-center gap-3">
                <div className="h-9 w-9 rounded-xl bg-white/10 border border-white/15 flex items-center justify-center backdrop-blur">
                  <LOGO_SVG />
                </div>
                <div className="leading-none">
                  <div className="font-extrabold tracking-[-0.02em] text-[18px] text-white">PAN OCEAN</div>
                  <div className="text-[10px] tracking-[0.18em] font-semibold text-[var(--cyan)] uppercase -mt-0.5">Oil Corporation</div>
                </div>
              </div>
              <p className="mt-6 text-[14px] leading-[1.7] text-white/60 max-w-[340px] font-[Inter]">
                Pan Ocean Oil Corporation Nigeria Limited operates within Nigeria's oil and gas industry. Corporate website providing factual profile and contact.
              </p>
              <div className="mt-6 inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/10 border border-white/15 text-[11px] text-white/70">
                <span className="h-1.5 w-1.5 rounded-full bg-[var(--teal)]" />
                Victoria Island, Lagos, Nigeria
              </div>
            </div>

            <div>
              <div className="text-[12px] tracking-[0.15em] font-bold uppercase text-white/40">Quick Links</div>
              <div className="mt-5 flex flex-col gap-3">
                {[
                  { label: "Home", id: "home" },
                  { label: "About Us", id: "about" },
                  { label: "Our Focus", id: "focus" },
                  { label: "Sustainability", id: "sustainability" },
                  { label: "Insights", id: "insights" },
                ].map((l) => (
                  <button key={l.id} onClick={() => scrollTo(l.id)} className="text-left text-[14px] text-white/60 hover:text-white transition focus-visible:outline focus-visible:outline-2 focus-visible:outline-[var(--cyan)]">
                    {l.label}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <div className="text-[12px] tracking-[0.15em] font-bold uppercase text-white/40">Contact</div>
              <div className="mt-5 space-y-3 text-[13px] leading-[1.6] text-white/60 font-[Inter]">
                <div>Plot 13/14, The Ark Towers, Ligali Ayorinde Street, Victoria Island, Lagos</div>
                <div className="inline-flex px-2.5 py-1 rounded-full bg-amber-500/15 border border-amber-400/20 text-amber-200 text-[11px]">Phone 13613000 — unverified</div>
                <div>
                  <button onClick={() => scrollTo("contact")} className="text-[var(--cyan)] hover:text-white transition font-medium focus-visible:outline focus-visible:outline-2 focus-visible:outline-[var(--cyan)]">
                    Corporate enquiry →
                  </button>
                </div>
              </div>
            </div>

            <div>
              <div className="text-[12px] tracking-[0.15em] font-bold uppercase text-white/40">Legal</div>
              <div className="mt-5 flex flex-col gap-3 text-[14px] text-white/60">
                <button className="text-left hover:text-white transition focus-visible:outline focus-visible:outline-2 focus-visible:outline-[var(--cyan)]">Privacy Policy</button>
                <button className="text-left hover:text-white transition focus-visible:outline focus-visible:outline-2 focus-visible:outline-[var(--cyan)]">Terms of Use</button>
                <div className="mt-4 text-[11px] leading-[1.5] text-white/40 font-[Inter]">
                  Imagery is conceptual and illustrative. No representation of company-owned assets without verification. Information provided for corporate discoverability.
                </div>
              </div>
            </div>
          </div>

          <div className="mt-16 pt-8 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="text-[12px] text-white/40 font-[Inter]">© {new Date().getFullYear()} Pan Ocean Oil Corporation Nigeria Limited. All rights reserved.</div>
            <div className="flex items-center gap-2 text-[11px] text-white/30">
              <span className="h-px w-8 bg-white/20" />
              Ocean-inspired • Luminous • Premium Corporate • 100% CSS Visuals
            </div>
          </div>
        </div>
      </footer>

      <button
        onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
        className={`fixed bottom-6 right-6 z-50 h-12 w-12 rounded-full bg-white border border-[var(--silver)] shadow-[0_12px_30px_rgba(7,59,92,0.15)] flex items-center justify-center text-[var(--deep)] hover:-translate-y-1 transition-all duration-300 ${
          showTop ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8 pointer-events-none"
        }`}
        aria-label="Scroll to top"
      >
        ↑
      </button>
    </div>
  );
}
